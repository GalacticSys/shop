create view cid3 as
select `leyou`.`tb_category`.`parent_id` AS `parent_id`
from `leyou`.`tb_category`
group by `leyou`.`tb_category`.`parent_id`;

-- comment on column cid3.parent_id not supported: 父类目id,顶级类目填0

